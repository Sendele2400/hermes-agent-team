# Video-Prompt — „Die Werkstatt füllt sich" (20 Sekunden)

Ziel: ein 20-Sekunden-Video in der echten Werkstatt. Startbild = `bilder/00_werkstatt.jpg`.
Personen = `bilder/01_thomas.jpg` (Thomas, der Verantwortliche) plus `bilder/KI-001` bis
`bilder/KI-037` (die 37 KI-Agenten).

## Zeitlicher Ablauf

**0–3 s — Allein, angespannt:**
Thomas sitzt allein am Schreibtisch und arbeitet konzentriert am Computer. Angespannte
Haltung, Blick auf die Monitore, leicht gerunzelte Stirn. Die Werkstatt ist leer und ruhig.

**3–8 s — Die ersten Agenten tauchen auf:**
Die ersten KI-Agenten erscheinen und eilen gestresst herbei. Sie unterstützen Thomas bei
seiner Arbeit: einer deutet auf einen Monitor, einer reicht Unterlagen, einer zieht Kabel,
einer hält ein Kanban-Board. Hektisch, aber zielgerichtet.

**8–15 s — Die Werkstatt füllt sich:**
Immer mehr Agenten strömen in die kleine Werkstatt — unter den Tisch, hinter die Pflanze,
auf den Tisch, zwischen die Maschinen, an das Whiteboard. Reges Treiben, kontrolliertes
Chaos. Je mehr Agenten anwesend sind, desto entspannter wird Thomas: er lehnt sich zurück,
die Anspannung weicht, er beginnt zu lächeln.

**15–20 s — Teamfoto:**
Alle 37 Agenten sind im Raum, geschäftiges Gewusel um Thomas. Schlussbild: alle stellen sich
für ein Teamfoto auf. Die Agenten wirken leicht erschöpft, aber lächeln. Thomas sitzt
tiefenentspannt in der Mitte. Die Kamera fährt leicht zurück, das Bild friert zum Teamfoto ein.

## Stil / Technik
- Fotorealistisch, dokumentarisch.
- Leicht bewegte Kamera (sanftes Gleiten/Driften), kein Schnitt.
- Natürliches, gleichmäßiges Deckenlicht wie im Referenzbild.
- 16:9, 20 Sekunden.
- Die Gesichter entsprechen den Referenzbildern.
- Kein Text, keine Logos, keine Wasserzeichen.

---

## English version (for the video model)

Goal: a 20-second video in the real workshop. Start frame = reference image
`bilder/00_werkstatt.jpg`. Characters = `bilder/01_thomas.jpg` (Thomas, the owner) plus
`bilder/KI-001` to `bilder/KI-037` (the 37 AI agents).

**0–3 s — alone and tense:** Thomas sits alone at the desk, working focused on the computer.
Tense posture, eyes on the monitors, slightly furrowed brow. The workshop is empty and quiet.

**3–8 s — the first agents appear:** the first AI agents arrive, rushing and stressed. They
help Thomas with his work: one points at a monitor, one hands over documents, one pulls
cables, one holds a kanban board. Hurried but purposeful.

**8–15 s — the workshop fills up:** more and more agents stream into the small workshop —
under the table, behind the plant, on the desk, between the machines, at the whiteboard.
Busy, controlled chaos. The more agents arrive, the more relaxed Thomas becomes: he leans
back, the tension fades, he starts to smile.

**15–20 s — team photo:** all 37 agents are in the room, a busy hubbub around Thomas.
Closing shot: everyone lines up for a team photo. The agents look slightly worn out but
smile. Thomas sits deeply relaxed in the middle. The camera slowly pulls back and the frame
freezes into the team photo.

Style: photorealistic, documentary, gently drifting camera (no cuts), natural even ceiling
light as in the reference image, 16:9, 20 seconds. Faces match the reference images.
No text, no logos, no watermark.

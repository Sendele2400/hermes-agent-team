# Referenzbilder — Beschreibung (für Higgsfield-Video)

## bilder/00_werkstatt.jpg
Die echte Werkstatt/Büro von Thomas Wahl: kombinierter Werkstatt-, Elektronik- und Büroraum.
Rechts ein langer Arbeitstisch mit mehreren Monitoren und Laptop, ein großer schwarzer
Werkzeugschrank, ein grüner „VIVIL"-Automat, Lupenleuchte, Wandlautsprecher und eine
Fisch-Deko (Billy Bass). Links eine größere Maschine mit Abdeckungen/Schläuchen (Laser),
Werkzeuge und Bauteile. In der Mitte ein schwarzer Bürostuhl mit Armlehnen und Rollen,
davor freie Bodenfläche. Helles, gleichmäßiges Deckenlicht.
**→ Dies ist das Startbild und der feste Hintergrund des Videos.**

## bilder/01_thomas.jpg
Thomas Wahl, der menschliche Verantwortliche („der Chef"). Sitzt im Video anfangs allein am
Schreibtisch — angespannt und konzentriert. Je mehr Agenten eintreffen, desto entspannter
wird er; am Ende tiefenentspannt in der Mitte des Teamfotos.

## Die 37 KI-Agenten (KI-001 bis KI-037)

| Datei | Name | Rolle | Auftritt im Video |
|---|---|---|---|
| KI-001_KI-Personalreferent.jpg | KI-Personalreferent | Bot-Verwaltung / HR | hält eine Personalakte und sortiert Unterlagen |
| KI-002_Projektleiter.jpg | Projektleiter | Orchestrierung / Delegation | mit Kanban-Board und Headset, koordiniert hektisch |
| KI-003_n8n-Workflow-Entwickler.jpg | n8n-Workflow-Entwickler | Workflow-Automatisierung | starrt auf ein verknotetes Workflow-Diagramm |
| KI-004_Full-Stack-Entwickler.jpg | Full-Stack-Entwickler | Programmierung | tippt Code am Laptop, leere Kaffeetassen |
| KI-005_Datenbankadministrator.jpg | Datenbankadministrator | Datenbanken | hantiert an einem Server-Rack / SQL-Terminal |
| KI-006_Software-Reverse-Engineer.jpg | Software-Reverse-Engineer | Software-Analyse | zerlegt Code, Lupe über einer Datei |
| KI-007_Bankkaufmann.jpg | Bankkaufmann | Bank / Finanzen | hält Kontoauszüge und prüft Überweisungen |
| KI-008_Steuerassistent.jpg | Steuerassistent | Steuern | hält Steuerunterlagen und einen Taschenrechner |
| KI-009_IT-Sicherheitsbeauftragter.jpg | IT-Sicherheitsbeauftragter | Sicherheit | mit Checkliste und Vorhängeschloss, prüft |
| KI-010_KI-Controller.jpg | KI-Controller | Token-/Kostenüberwachung | starrt auf ein Kosten-Dashboard und warnt |
| KI-011_Versicherungsmanager.jpg | Versicherungsmanager | Versicherungen | blättert in Versicherungspolicen |
| KI-012_Belegsachbearbeiter.jpg | Belegsachbearbeiter | Belegauswertung | sortiert Rechnungen und Belege |
| KI-013_Paperless-Administrator.jpg | Paperless-Administrator | Dokumentenablage | ordnet Dokumente und Tags |
| KI-014_Online-Portalmanager.jpg | Online-Portalmanager | Portal-Beschaffung | zieht Dokumente aus einem Kundenportal |
| KI-015_E-Mail-Assistent.jpg | E-Mail-Assistent | E-Mail-Posteingang | arbeitet einen Stapel E-Mails ab |
| KI-016_Deep-Research-Spezialist.jpg | Deep-Research-Spezialist | tiefe Recherche | liest einen Bericht mit Quellenverzeichnis |
| KI-017_Trendanalyst.jpg | Trendanalyst | Trend-Analyse | deutet auf einen YouTube-Trendgraphen |
| KI-018_UI-UX-Designer.jpg | UI-UX-Designer | visuelles Design | hält ein Wireframe / Design-Mockup |
| KI-019_draw.io-Administrator.jpg | draw.io-Administrator | Diagramme | zeichnet ein Flowchart |
| KI-020_Content-Creator.jpg | Content-Creator | Texte / Redaktion | schreibt Text am Laptop |
| KI-021_Smart-Home-Assistent.jpg | Smart-Home-Assistent | Smart Home | steuert Geräte per Tablet |
| KI-022_KNX-Techniker.jpg | KNX-Techniker | KNX/Gebäudeautomation | hält einen Gebäudeplan / ETS |
| KI-023_Netzwerkadministrator.jpg | Netzwerkadministrator | Netzwerk / Homelab | zieht Netzwerkkabel, Switch in der Hand |
| KI-024_Home-Assistant-Administrator.jpg | Home-Assistant-Administrator | Home Assistant | konfiguriert die HA-Instanz |
| KI-025_Stromlaufplaner.jpg | Stromlaufplaner | Stromlaufpläne | entrollt einen Schaltplan |
| KI-026_Fusion-Konstrukteur.jpg | Fusion-Konstrukteur | CAD-Konstruktion | hält ein 3D-Bauteil / CAD-Modell |
| KI-027_Vibe-Coding-Berater.jpg | Vibe-Coding-Berater | Vibe-Coding-Beratung | berät am Flipchart |
| KI-028_Sparring-Partner.jpg | Sparring-Partner | Coaching / Sparring | macht sich Notizen, reflektiert |
| KI-029_Familienplaner.jpg | Familienplaner | Familienkalender | zeigt auf einen Kalender mit Terminen |
| KI-030_WhatsApp-Assistent.jpg | WhatsApp-Assistent | mobiler Eingang | tippt auf einem Smartphone |
| KI-031_Billy-Bass.jpg | Billy Bass | Unterhaltung (Singfisch) | der sprechende Fisch an der Wand |
| KI-032_Vector.jpg | Vector | Roboter-Assistent | kleiner Roboter auf dem Tisch |
| KI-033_Kryptohändler.jpg | Kryptohändler | Krypto-Trading | starrt auf Preis-Charts |
| KI-034_Video-Archivar.jpg | Video-Archivar | Video-Archivierung | schneidet eine Video-Timeline |
| KI-035_xTool-Assistent.jpg | xTool-Assistent | Laser-Fertigung | kalibriert die Lasermaschine |
| KI-036_Higgsfield-Mediengestalter.jpg | Higgsfield-Mediengestalter | Bild-/Video-Generierung | rendert Medien, beobachtet den Polling-Fortschritt |
| KI-037_Lean-Manager.jpg | Lean-Manager | Ideenkiste / Lean | sammelt Ideen, macht Notizen |
